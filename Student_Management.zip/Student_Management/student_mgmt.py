import json, os

DATA_FILE = "data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return []

def save_data(students):
    with open(DATA_FILE, "w") as f:
        json.dump(students, f, indent=2)

students = load_data()

# add student

def add_student():
    roll = input("Roll no: ").strip()
    if any(s['roll_no'] == roll for s in students):
        print("Roll no exists.")
        return
    name = input("Name: ").strip()
    grade = input("Grade: ").strip()
    students.append({"roll_no": roll, "name": name, "grade": grade})
    print("Added.")

# view student

def view_students():
    if not students:
        print("No records.")
        return
    print(f"{'Roll':<10}{'Name':<20}{'Grade':<6}")
    for s in students:
        print(f"{s['roll_no']:<10}{s['name']:<20}{s['grade']:<6}")

# search student

def search(roll):
    for s in students:
        if s['roll_no'] == roll:
            return s
    return None

# update student

def update_student():
    roll = input("Roll to update: ").strip()
    s = search(roll)
    if not s:
        print("Not found")
        return
    new_name = input(f"Name [{s['name']}]: ").strip()
    if new_name:
        s['name'] = new_name
    new_grade = input(f"Grade [{s['grade']}]: ").strip()
    if new_grade:
        s['grade'] = new_grade
    print("Updated.")

# delete student

def delete_student():
    roll = input("Roll to delete: ").strip()
    s = search(roll)
    if not s:
        print("Not found")
        return
    if input("Delete? (y/N): ").lower() == 'y':
        students.remove(s)
        print("Deleted.")

# mainmenu loop

def main():
    while True:
        print("\n1) Add \n2) View \n3) Search \n4) Update \n5) Delete \n6) Exit \n")
        choice = input("Choice: ").strip()
        if choice == "1":
            add_student()
        elif choice == "2":
            view_students()
        elif choice == "3":
            roll = input("Enter roll no to search: ").strip()
            result = search(roll)
            print(result if result else "Not found.")
        elif choice == "4":
            update_student()
        elif choice == "5":
            delete_student()
        elif choice == "6":
            save_data(students)
            print("Data saved. Exiting.")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()

    