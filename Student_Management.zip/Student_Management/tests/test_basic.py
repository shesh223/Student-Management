
### Unit Tests

import unittest

class TestStudentMgmt(unittest.TestCase):
    def test_add_student(self):
        students = []
        students.append({"roll_no": "101", "name": "Alice", "grade": "A"})
        self.assertEqual(len(students), 1)
        self.assertEqual(students[0]['name'], "Alice")

if __name__ == '__main__':
    unittest.main()