# Student Management System

Console-based Python app to manage student records.

## Features
- Add, View, Search, Update, Delete students
- JSON persistence (data.json)

## How to Run
```bash
python student_mgmt.py